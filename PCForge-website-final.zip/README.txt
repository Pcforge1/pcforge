# PCForge — No-Stripe Order Website

This version does NOT use Stripe or any online payment processor.

## How it works

1. Customer chooses one part from each of the 8 categories.
2. The site calculates the estimated parts total + $75 build/testing fee.
3. Customer clicks "Request this build."
4. Customer submits name, email, optional phone, and notes.
5. Supabase creates a pending order and stores the selected parts.
6. The customer gets an order-request ID.
7. You contact the customer to confirm availability, final price, and payment method.

## Supabase

The site uses this existing project:

https://oasckbwthiavmyuhmyiz.supabase.co

The database migration `add_non_stripe_build_request_submission` adds:
- `customer_phone`
- `customer_notes`
- `submit_pc_build_request(...)`

The public parts table is read through Supabase REST. The order is submitted through the RPC function.

## Running locally

Because browsers can restrict requests from `file://`, serve the folder with a local web server.

For example, with Python installed:

    python3 -m http.server 8000

Then open:

    http://localhost:8000

## Important

The frontend no longer calls the old Stripe checkout Edge Function.

The old Stripe database columns/functions and Edge Functions may still exist in the Supabase project, but this website does not use them. They can be cleaned up separately once you're sure you don't need the old Stripe setup.


VISUAL UPDATE
- Added generated PCForge gaming hero background: assets/pcforge-hero.png
- Added guaranteed visible component illustrations for every part card, with real Supabase image_url support if images are later added.
- Updated checkout wording and kept the no-Stripe order-request flow.
