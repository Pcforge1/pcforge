const SUPABASE_URL = "https://oasckbwthiavmyuhmyiz.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_WT4qALE5VKnEllxiRkc4uw_NuLPYENh";
const BUILD_FEE_CENTS = 7500;

const categories = ["CPU","GPU","Motherboard","RAM","Storage","Case","PSU","Cooling"];
let parts = [];
const selected = {};

const money = cents => `$${(cents / 100).toFixed(2)}`;
const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function loadParts() {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/pc_parts?active=eq.true&order=category,name`, {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}` }
  });
  if (!res.ok) throw new Error("Could not load parts.");
  parts = await res.json();
  renderParts();
  updateSummary();
}

function partImage(part) {
  const category = String(part.category || "PC").toUpperCase();
  const colors = {
    CPU: ["#168fff", "#49b7ff"], GPU: ["#168fff", "#7f5cff"],
    MOTHERBOARD: ["#168fff", "#20d8a3"], RAM: ["#168fff", "#b36bff"],
    STORAGE: ["#20d8a3", "#168fff"], CASE: ["#168fff", "#4a6cff"],
    PSU: ["#4a6cff", "#168fff"], COOLING: ["#20d8a3", "#168fff"]
  };
  const [a,b] = colors[category] || ["#168fff","#4a6cff"];
  let shape = '';
  if (category === 'CPU') shape = '<rect x="42" y="20" width="76" height="52" rx="6"/><rect x="58" y="33" width="44" height="26" rx="3"/>';
  else if (category === 'GPU') shape = '<rect x="20" y="29" width="120" height="34" rx="6"/><circle cx="55" cy="46" r="10"/><circle cx="105" cy="46" r="10"/>';
  else if (category === 'MOTHERBOARD') shape = '<rect x="30" y="15" width="100" height="70" rx="4"/><rect x="44" y="27" width="35" height="25"/><rect x="87" y="27" width="28" height="7"/><rect x="87" y="40" width="28" height="7"/>';
  else if (category === 'RAM') shape = '<rect x="25" y="34" width="110" height="22" rx="4"/><path d="M38 34v22m16-22v22m16-22v22m16-22v22m16-22v22m16-22v22"/>';
  else if (category === 'STORAGE') shape = '<rect x="42" y="16" width="76" height="68" rx="5"/><circle cx="80" cy="48" r="17"/><circle cx="80" cy="48" r="4"/>';
  else if (category === 'CASE') shape = '<rect x="46" y="10" width="68" height="80" rx="7"/><circle cx="80" cy="31" r="10"/><circle cx="80" cy="57" r="10"/><path d="M56 77h48"/>';
  else if (category === 'PSU') shape = '<rect x="31" y="23" width="98" height="54" rx="6"/><circle cx="58" cy="50" r="16"/><path d="M58 38v24m-12-12h24"/>';
  else shape = '<circle cx="80" cy="48" r="30"/><circle cx="80" cy="48" r="9"/><path d="M80 18v21m30 9H89m-9 30V57M50 48h21"/>';
  const safe = encodeURIComponent(category);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="160" height="100" viewBox="0 0 160 100"><defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="160" height="100" rx="12" fill="#07111d"/><rect x="5" y="5" width="150" height="90" rx="10" fill="none" stroke="url(#g)" stroke-opacity=".45"/><g fill="none" stroke="url(#g)" stroke-width="3">${shape}</g><text x="80" y="94" text-anchor="middle" fill="#d9ecff" font-size="8" font-family="Arial" font-weight="700">${safe}</text></svg>`;
  return 'data:image/svg+xml;charset=UTF-8,' + svg;
}

function renderParts() {
  const root = document.getElementById("parts");
  root.innerHTML = categories.map(category => {
    const items = parts.filter(p => p.category === category);
    return `<div class="category">
      <h3>${esc(category)}</h3>
      ${items.map(p => `<label class="part-option ${selected[category] === p.id ? "selected" : ""}">
        <input type="radio" name="${esc(category)}" value="${esc(p.id)}" ${selected[category] === p.id ? "checked" : ""}>
        <img class="part-image" src="${partImage(p)}" alt="${esc(p.name)}" loading="lazy">
        <div class="part-copy"><div class="part-name">${esc(p.name)}</div><div class="part-desc">${esc(p.description || "")}</div></div>
        <div class="part-price">${money(p.price_cents)}</div>
      </label>`).join("") || `<div class="empty">No parts available.</div>`}
    </div>`;
  }).join("");

  root.querySelectorAll("input[type=radio]").forEach(input => {
    input.addEventListener("change", () => {
      selected[input.name] = input.value;
      renderParts();
      updateSummary();
    });
  });
}
function updateSummary() {
  const chosen = categories.map(c => parts.find(p => p.id === selected[c])).filter(Boolean);
  const subtotal = chosen.reduce((sum, p) => sum + p.price_cents, 0);
  document.getElementById("summary-count").textContent = `${chosen.length}/8`;
  document.getElementById("progress").textContent = `${chosen.length} / 8 selected`;
  document.getElementById("parts-total").textContent = money(subtotal);
  document.getElementById("grand-total").textContent = money(subtotal + BUILD_FEE_CENTS);
  document.getElementById("request-btn").disabled = chosen.length !== 8;

  document.getElementById("summary-items").innerHTML = chosen.length
    ? chosen.map(p => `<div class="summary-item"><span>${esc(p.category)}<br><b>${esc(p.name)}</b></span><span>${money(p.price_cents)}</span></div>`).join("")
    : `<div class="empty">Select parts to see your build here.</div>`;
}

function openModal() {
  if (categories.some(c => !selected[c])) return;
  document.getElementById("modal").classList.remove("hidden");
  document.getElementById("customer-name").focus();
}

function closeModal() {
  document.getElementById("modal").classList.add("hidden");
  document.getElementById("form-error").classList.add("hidden");
}

async function submitOrder(event) {
  event.preventDefault();
  const errorBox = document.getElementById("form-error");
  const button = event.submitter;
  errorBox.classList.add("hidden");
  button.disabled = true;
  button.textContent = "Submitting…";

  try {
    const payload = {
      p_part_ids: categories.map(c => selected[c]),
      p_build_fee_cents: BUILD_FEE_CENTS,
      p_customer_name: document.getElementById("customer-name").value.trim(),
      p_customer_email: document.getElementById("customer-email").value.trim(),
      p_customer_phone: document.getElementById("customer-phone").value.trim(),
      p_customer_notes: document.getElementById("customer-notes").value.trim()
    };

    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/submit_pc_build_request`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(text.replace(/["{}]/g, "").slice(0, 300) || "Could not submit the build request.");
    }

    const orderId = await res.json();
    window.location.href = `success.html?order_id=${encodeURIComponent(orderId)}`;
  } catch (err) {
    errorBox.textContent = err.message || "Something went wrong. Please try again.";
    errorBox.classList.remove("hidden");
    button.disabled = false;
    button.textContent = "Place order request →";
  }
}

document.getElementById("request-btn").addEventListener("click", openModal);
document.getElementById("close-modal").addEventListener("click", closeModal);
document.querySelector(".modal-backdrop").addEventListener("click", closeModal);
document.getElementById("order-form").addEventListener("submit", submitOrder);
document.addEventListener("keydown", event => { if (event.key === "Escape") closeModal(); });

loadParts().catch(err => {
  document.getElementById("parts").innerHTML = `<div class="form-error">${esc(err.message)}</div>`;
});
